import {View, Animated, Easing} from 'react-native';
import React, {useEffect, useMemo, useRef} from 'react';

import LinearGradient from 'react-native-linear-gradient';
import MaskedView from '@react-native-masked-view/masked-view';

import {marked} from 'marked';
import {RenderHTMLSource} from 'react-native-render-html';

marked.use({});

interface MarkdownViewProps {
  markdownText: string;
  maxMessageWidth: number;
  selectable?: boolean;
  /** Texto ainda sendo gerado: aplica fade-in suave na borda de baixo. */
  streaming?: boolean;
}

// Altura da zona de transição (última linha "aparecendo").
const FADE_EDGE_HEIGHT = 30;

const isEmptyContent = (content: string): boolean => {
  return !content || content.trim() === '';
};

/**
 * Renders a markdown string inside the app-level RenderHTML provider tree.
 * The engine (parser + tagsStyles + renderers) lives on `MarkdownProvider`
 * at the app root; only `source` and `contentWidth` change here, so per-
 * token streaming updates stay cheap.
 *
 * NOTE: `selectable` is accepted for API compatibility but is currently
 * fixed at the provider level. If a caller ever needs a selectable variant
 * a separate provider scope would have to host it.
 */
export const MarkdownView: React.FC<MarkdownViewProps> = React.memo(
  ({markdownText, maxMessageWidth, streaming}) => {
    const htmlContent = useMemo(
      () => marked(markdownText) as string,
      [markdownText],
    );
    const source = useMemo(() => ({html: htmlContent}), [htmlContent]);

    // Fade-in de entrada quando o bloco aparece pela primeira vez.
    const appear = useRef(new Animated.Value(streaming ? 0 : 1)).current;
    useEffect(() => {
      if (streaming) {
        Animated.timing(appear, {
          toValue: 1,
          duration: 220,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }).start();
      }
    }, [appear, streaming]);

    const content = !isEmptyContent(markdownText) && (
      <RenderHTMLSource source={source} contentWidth={maxMessageWidth} />
    );

    // Durante o streaming, a borda de baixo do texto some suavemente
    // (máscara em degradê). O texto novo "emerge" e vai ficando nítido
    // conforme as linhas seguintes empurram ele para cima.
    if (streaming && content) {
      return (
        <Animated.View style={{opacity: appear}}>
          <MaskedView
            testID="markdown-content"
            style={{maxWidth: maxMessageWidth}}
            maskElement={
              <View style={{flex: 1}}>
                <View style={{flex: 1, backgroundColor: '#000'}} />
                <LinearGradient
                  colors={['#000000', 'rgba(0,0,0,0.25)']}
                  style={{height: FADE_EDGE_HEIGHT}}
                />
              </View>
            }>
            {content}
          </MaskedView>
        </Animated.View>
      );
    }

    return (
      <View testID="markdown-content" style={{maxWidth: maxMessageWidth}}>
        {content}
      </View>
    );
  },
  (prevProps, nextProps) =>
    prevProps.markdownText === nextProps.markdownText &&
    prevProps.maxMessageWidth === nextProps.maxMessageWidth &&
    prevProps.selectable === nextProps.selectable &&
    prevProps.streaming === nextProps.streaming,
);
